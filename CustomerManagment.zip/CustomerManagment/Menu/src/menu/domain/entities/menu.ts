export class Menu {
    constructor(
    public pdf:string,
    public retaurant_id:number
    ){}
}