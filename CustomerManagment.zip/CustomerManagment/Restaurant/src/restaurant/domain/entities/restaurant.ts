export class Restaurant {
    constructor(
    public name_local: string,
    public description: string,
    public gender:string,
    public image: string,
    public address: string,
    public coordinate:string,
    public status:boolean,
    public user_id: string
    ){}
}